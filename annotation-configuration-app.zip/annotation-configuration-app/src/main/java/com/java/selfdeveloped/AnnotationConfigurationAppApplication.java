package com.java.selfdeveloped;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.java.selfdeveloped.entity.Student;
import com.java.selfdeveloped.repository.StudentRepository;

@SpringBootApplication
public class AnnotationConfigurationAppApplication {

    private StudentRepository studentRepository;

    public AnnotationConfigurationAppApplication(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @PostConstruct
    public void initStudents() {
        studentRepository.saveAll(Stream.of(
                        new Student(101, "Kaushal", 14, "Science"),
                        new Student(102, "Santosh", 48, "Arts"),
                        new Student(103, "Rajesh", 16, "Commerce"),
                        new Student(104, "Sam", 12, "Arts"))
                .collect(Collectors.toList()));
    }
    
	public static void main(String[] args) {
		SpringApplication.run(AnnotationConfigurationAppApplication.class, args);
	}

}
