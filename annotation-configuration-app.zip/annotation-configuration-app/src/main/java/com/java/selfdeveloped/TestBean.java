package com.java.selfdeveloped;

import org.springframework.stereotype.Component;

public class TestBean {

    public void method(){
        System.out.println("TestBean method logic excuted ");
    }
}
