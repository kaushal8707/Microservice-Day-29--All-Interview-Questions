package com.java.selfdeveloped;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class HighestPaidEmployeeFromDepartment {
	public static void main(String[] args) {
		List<Employee> employees = Stream.of(
						new Employee(1, "Basant", "DEV", 50000),
						new Employee(8, "santhosh", "DEV", 80000),
						new Employee(3, "pratik", "QA", 60000),
						new Employee(9, "Dipak", "QA", 90000),
						new Employee(4, "Bikash", "DEVOPS", 40000))
				 .collect(Collectors.toList());
		
		//Approach 1
		Comparator<Employee> compareBySalary = Comparator.comparing(Employee::getSalary);
		Map<String, Optional<Employee>> employeeMap = employees.stream()
										.collect(Collectors.groupingBy(Employee::getDept, 
														Collectors.reducing(BinaryOperator.maxBy(compareBySalary))));
		System.out.println(employeeMap);
		
		//Approach 2
		Map<String, Employee> employeeMap1 = employees.stream()
										.collect(Collectors.groupingBy(Employee::getDept, 
												Collectors.collectingAndThen(Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary)),Optional::get)));
		System.out.println(employeeMap1);
	}
}
