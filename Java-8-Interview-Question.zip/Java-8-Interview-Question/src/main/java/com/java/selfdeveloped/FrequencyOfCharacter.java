package com.java.selfdeveloped;
import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FrequencyOfCharacter {
	public static void main(String[] args) {
		String input = "kaushal";
		Stream<String> streams = Arrays.stream(input.split(""));
		//stream.forEach(System.out::println);
		Map<String, Long> countMap = streams.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(countMap);	
	}
}
