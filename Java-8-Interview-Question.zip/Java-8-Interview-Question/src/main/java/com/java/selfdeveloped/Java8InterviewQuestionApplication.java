package com.java.selfdeveloped;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java8InterviewQuestionApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java8InterviewQuestionApplication.class, args);
	}

}
