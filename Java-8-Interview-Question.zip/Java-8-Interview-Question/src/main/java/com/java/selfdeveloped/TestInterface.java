package com.java.selfdeveloped;

@FunctionalInterface
public interface TestInterface extends UPIPayment{

	//void test();
}
