package com.java.selfdeveloped;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
public class TestStreamAPI {
	public static void main(String[] args) {
		List<Integer> numList=
					Arrays.asList(23,4,6,8,9,1,2,10);
		//static method reference
		//numList.stream().filter(n -> n>5).sorted().forEach(TestStreamAPI::printElement);
		
		//instance method reference
		TestStreamAPI test = new TestStreamAPI();
		numList.stream().filter(n -> n>5).sorted().forEach(test::printElement);
	}
	
	public void printElement(int i) {
		System.out.println(i); 
	}
}
