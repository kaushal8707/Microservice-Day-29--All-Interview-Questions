package com.java.selfdeveloped;

@FunctionalInterface
public interface MyFunction { 
	String test(String s1, String s2);
}
