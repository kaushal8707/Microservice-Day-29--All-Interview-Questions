package com.java.collection;
import java.util.ArrayList;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		ArrayList arrayList = new ArrayList<String>();
		List list = new ArrayList<String>();
		//Parent parent = new Child();   -- Runtime Polymorphism
	}
}
