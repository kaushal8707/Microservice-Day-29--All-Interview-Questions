package com.java.collection;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapDemo {
	public static void main(String[] args) {
		Map<String, String> map = new TreeMap();
		map.put("a","xyz");
		map.put("d","ksh");
		map.put("b","lvjdf");
		System.out.println(map);
	}
}
